//
//  ViewController.swift
//  MRTowerDiffence
//
//  Created by 洞井僚太 on 2019/08/24.
//  Copyright © 2019 洞井僚太. All rights reserved.
//

import UIKit
import SceneKit
import ARKit

class ViewController: UIViewController, ARSCNViewDelegate,SCNPhysicsContactDelegate {
    var enemies:[SCNNode]=[]
    @IBOutlet var sceneView: ARSCNView!
    var bullets:[SCNNode] = []
    let bulletCategory = 0x0000
    let enemyCategory = 0x0001
    var score = 0
    var scoreLabel: UILabel!
    var spawnTimer:Timer!
    var counter = 0
    //let scoreLabelView:
    override func viewDidLoad() {
        super.viewDidLoad()
        scoreLabel = UILabel()
        scoreLabel.text = "score:\(score)"
        scoreLabel.font = UIFont.systemFont(ofSize: 30.0)
     /*   scoreLabel.frame.origin.x = view.frame.width/2-20
        scoreLabel.frame.origin.y = view.frame.height/2
 view.addSubview(scoreLabel)*/
        
        //scoreLabel.font
       /* let scene = GameScene()
        let scnView = self.view as! SCNView
        scnView.backgroundColor = UIColor.black
        scnView.scene = scene
        scnView.showsStatistics = true
 scnView.allowsCameraControl = true*/
        // Set the view's delegate
        sceneView.delegate = self
        sceneView.scene.physicsWorld.contactDelegate = self
        // Show statistics such as fps and timing information
        sceneView.showsStatistics = true
        spawnTimer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true, block: {_ in self.addEnemy()})
        // Create a new scene
        let scene = SCNScene(named: "art.scnassets/enemy_red_walk.scn")!
        
        // Set the scene to the view
        sceneView.scene = scene
        
    }
    func addEnemy(){
        print("kokoniiru")
     var enemy = SCNNode()
        enemy.geometry = SCNBox(width: 4, height: 4, length: 4, chamferRadius: 0)
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.white
        enemy.geometry?.materials = [material]
        enemy.physicsBody?.categoryBitMask = enemyCategory
        enemy.physicsBody?.collisionBitMask = bulletCategory
        enemy.physicsBody?.contactTestBitMask = bulletCategory
        enemy.position = SCNVector3Make(Float(counter*10),0,-50)
        enemies.append(enemy)
        let targetPos = SCNVector3Make(0,0,0)
       //let target = camera.convertPosition(targetPos, to: nil)
        let action = SCNAction.move(to: targetPos, duration: 100)
        //let remove = SCNAction.removeFromParentNode()
        enemy.runAction(action)
        sceneView.scene.rootNode.addChildNode(enemy)
       /* let sceneSource = SCNSceneSource(url: url, options: nil)!
        guard let modelNode = sceneSource.entryWithIdentifier("enemy_red_walk2", withClass: SCNNode.self) else {
            fatalError()
        }*/
        counter += 10
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // Create a session configuration
        let configuration = ARWorldTrackingConfiguration()
        
        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
      //  let scnView = self.view as! SCNView
        
     //   scnView.scene?.rootNode.addChildNode(ballNode.clone())
        guard let camera = sceneView.pointOfView else {
            return
        }
        var bullet = SCNNode()
        bullet.geometry = SCNSphere(radius: 0.5)
        let material = SCNMaterial()
        material.diffuse.contents = UIColor.brown
        bullet.geometry?.materials = [material]
        bullet.position = camera.position
        bullet.physicsBody?.categoryBitMask = bulletCategory
        bullet.physicsBody?.collisionBitMask = enemyCategory
        bullet.physicsBody?.contactTestBitMask = enemyCategory
        bullets.append(bullet)
        //let scene = SCNScene(named: "art.scnassets/ship.scn")!
        
        let targetPos = SCNVector3Make(0,0,-100)
        let target = camera.convertPosition(targetPos, to: nil)
        let action = SCNAction.move(to: target, duration: 1)
        let remove = SCNAction.removeFromParentNode()
        bullet.runAction(SCNAction.sequence([action,remove]))
        sceneView.scene.rootNode.addChildNode(bullet)
    }
    func physicsWorld(_ world: SCNPhysicsWorld, didBegin contact: SCNPhysicsContact) {
        let nodeA = contact.nodeA
        let nodeB = contact.nodeB
        var enemy = SCNNode()
        var bullet = SCNNode()
        if nodeA.categoryBitMask == bulletCategory{
            enemy = nodeB
            bullet = nodeA
        }else{
            enemy = nodeA
            bullet = nodeB
        }
        for i in 0..<enemies.count{
            if enemy.position.x == enemies[i].position.x{
                enemies[i].removeFromParentNode()
                enemies.remove(at:i)
            }
            
        }
        bullet.removeFromParentNode()
        score += 1000
    }
    // MARK: - ARSCNViewDelegate
    
    /*
     // Override to create and configure nodes for anchors added to the view's session.
     func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
     let node = SCNNode()
     
     return node
     }
     */  /*func gameover(){
     for enemy in enemies{
     //if (enemy.position == SCNVector3(x:0,y:0,z:0))
     {
     
     }
     }
     }*/
    /* func hitTest(point:CGPoint,types:ARHitTestResult.ResultType)->[ARHitTestResult]{
     
     }*/
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
    
}
